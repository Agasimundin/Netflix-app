# ReactNativeNetflix
React-Native  app like netflix app
