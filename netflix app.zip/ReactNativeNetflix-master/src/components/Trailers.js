import React, {Component} from 'react'
import {View,Text} from 'react-native'

class Trailers extends Component{
    render(){
        return (
            <Text>Trailers</Text>
        )
    }
}

export default Trailers
