import { AppRegistry } from 'react-native';
import index from './src/index';

AppRegistry.registerComponent('NetflixApp', () => index);
